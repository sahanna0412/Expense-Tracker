
package expense_income_tracker;
/**
 *
 * @author MADHUMITHA
 */
public class Expense_Income_Tracker {

   
    public static void main(String[] args) {
     
      new ExpenseIncomeTracker().setLocationRelativeTo(null);
       
    }
    
}
